module.exports = {

"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/src/locales/en.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("{\"appName\":\"AquaVita\",\"nav\":{\"home\":\"Home\",\"ourMission\":\"Our Mission\",\"solutions\":\"Our Impact\",\"projects\":\"Projects\",\"blog\":\"Blog\",\"contact\":\"Contact\",\"language\":\"Language\"},\"loading\":\"Loading...\",\"hero\":{},\"introCard\":{\"question\":\"Can you imagine living in a world without water? How would you perform activities like cooking, washing dishes, and cleaning yourself?\",\"statement\":\"Faced with the context of water scarcity, Wayru arrived to redefine water use, providing sustainability, well-being, and hygiene in every home.\"},\"phrases\":{\"phrase1\":\"1 in 3 people worldwide lack access to safe drinking water.\",\"phrase1_icon_alt\":\"People icon\",\"phrase2\":\"3 million Peruvians are affected by this situation.\",\"phrase2_icon_alt\":\"Peru map icon\"},\"informativeVideo\":{\"title\":\"Our Purpose\",\"description\":\"We are a social enterprise committed to improving the quality of life for communities without access to potable water networks and facing water scarcity. We seek to:\",\"tab1_title\":\"Impact\",\"tab1_content\":\"Positively impact society through social projects, educational workshops, and innovative solutions.\",\"tab2_title\":\"Contribute\",\"tab2_content\":\"Contribute to sustainable development, promoting responsible water management and the conservation of our natural resources.\",\"tab3_title\":\"Empower\",\"tab3_content\":\"Empower more families to be part of the change our planet needs, through sustainable water disposal and consumption practices.\",\"tab4_title\":\"Inspire\",\"tab4_content\":\"Inspire more actors to join our cause and act against water scarcity.\"},\"productSection\":{\"title\":\"Our Innovative Product\",\"item1_title\":\"Atmospheric Water Generation\",\"item1_description\":\"Cutting-edge technology that extracts pure drinking water directly from the air, providing a sustainable solution for arid regions.\",\"item2_title\":\"Smart Water Filtration\",\"item2_description\":\"Advanced filtration systems ensuring safe and clean water, adaptable for homes, communities, and emergency situations.\",\"item3_title\":\"Water Conservation Kits\",\"item3_description\":\"Easy-to-use kits and educational materials to help households reduce water consumption and adopt water-saving habits.\"},\"eventsSection\":{\"title\":\"Community & Events\",\"event1_title\":\"Workshop: Water for All\",\"event1_description\":\"Join our educational workshop on sustainable water practices and community involvement. Learn how you can make a difference.\",\"event2_title\":\"AquaRun Charity Event\",\"event2_description\":\"Participate in our annual charity run to raise funds for water projects in underserved communities. Every step counts!\",\"event3_title\":\"Innovation Summit\",\"event3_description\":\"Discover the latest advancements in water technology and policy at our annual summit. Connect with experts and leaders.\"},\"newsSection\":{\"mainTitle\":\"For a happier city\",\"mainSubtitle\":\"Wayru, the project aiming to make Lima more accessible to drinking water\",\"readMoreButton\":\"Read More\",\"item1\":{\"title\":\"“For a happier city”: Wayru, the project aiming to make Lima more accessible to drinking water\",\"subtitle\":\"Interview for Somos magazine of the Peruvian newspaper “El Comercio”\"},\"item2\":{\"title\":\"Entrepreneurs combat the water crisis in Peru\",\"subtitle\":\"Interview for the Chilean newspaper DF SUD\"},\"item3\":{\"title\":\"Innovative Peruvians create a portable shower that needs no pipes or electricity\",\"subtitle\":\"Press release in the Peruvian news agency “Andina”\"},\"item4\":{\"title\":\"Meet Wayru Perú, winners of the UPC Protagonists of Change for SDGs 2023 program\",\"subtitle\":\"Press release in the Peruvian newspaper “RPP”\"},\"item5\":{\"title\":\"Wayru Perú, finalist of Perumin Inspira 2023, addresses limited water access problem\",\"subtitle\":\"Television interview for the “Red de Comunicación Regional (RCR)” platform.\"},\"item6\":{\"title\":\"Wayru Perú participates in international IDB and UN event during Water Week 2023\",\"subtitle\":\"Presentation at the “Source of Innovation: Accelerating SDG 6” conference organized by the Inter-American Development Bank and the United Nations.\"},\"item7\":{\"title\":\"The portable shower arrived to revolutionize hygiene in Peruvian homes\",\"subtitle\":\"Press release in the international free newspaper “Publimetro”\"},\"item8\":{\"title\":\"Entrepreneurs from the U.S. and Peru earn places in the annual ASME ISHOW cohort with accessible clean energy and water innovations\",\"subtitle\":\"Press release from the “American Society of Mechanical Engineers (ASME)”\"},\"item9\":{\"title\":\"Peruvian geographer won international contest with portable shower project\",\"subtitle\":\"Press release in the Peruvian newspaper “La República”.\"},\"item10\":{\"title\":\"Wayru on TV Perú: Innovative Solutions for Water Scarcity\",\"subtitle\":\"Segment in the \\\"Generación Bicentenario\\\" program broadcast on the public television network TV Perú.\"},\"item11\":{\"title\":\"PUCP students and alumna are the creators of Wayru, project that won first place in the IDB E-Hackathon\",\"subtitle\":\"Interview for the “Punto Edu” bulletin, news portal of the Pontifical Catholic University of Peru.\"}},\"impactSection\":{\"title\":\"Want to know how Wayru is transforming the world?\",\"description\":\"Learn more about our impact on communities, the environment, and society.\",\"shareLabel\":\"Share this page:\",\"shareFacebook\":\"Share on Facebook\",\"shareTwitter\":\"Share on Twitter\",\"shareLinkedIn\":\"Share on LinkedIn\",\"shareEmail\":\"Share via Email\"},\"serParte\":{\"title\":\"Be Part of the Change\",\"introText\":\"Your contribution can make a significant difference. Explore how you can get involved and help us bring clean water to more communities.\",\"prevSlide\":\"Previous slide\",\"nextSlide\":\"Next slide\",\"slide1_title\":\"Sponsor a Project\",\"slide1_description\":\"Companies and individuals can fund specific projects to bring water and environmental education to more communities. Let's build together!\",\"slide1_button\":\"Contact Us\",\"slide2_title\":\"Inspire and Connect\",\"slide2_description\":\"Share your knowledge or connect us with communities that could benefit from our projects. Be part of the positive impact!\",\"slide2_button\":\"Build with Us\",\"slide3_title\":\"Share Our Work\",\"slide3_description\":\"Follow us on social media and share our work with those around you. Help us spread the message of sustainability!\",\"slide3_button\":\"Spread the Word\",\"contactUs\":\"Contact Us\",\"buildWithUs\":\"Build with Us\",\"form\":{\"description\":\"Fill out the form below and we'll get in touch with you shortly.\",\"name\":\"Name\",\"email\":\"Email\",\"message\":\"Message\",\"send\":\"Send Message\",\"submitted\":\"Thank you! Your message has been sent.\"},\"social\":{\"title\":\"Spread the Word\",\"description\":\"Follow us and share our mission on your social networks.\"}},\"alliesSection\":{\"title\":\"Together We Make a Difference\",\"description\":\"Meet our partners who share our vision and join us in our commitment to create a more sustainable world.\",\"button\":\"Learn More\"},\"homeContactSection\":{\"title\":\"Let's build a sustainable future\",\"subtitle\":\"CONTACT US!\",\"imageAlt\":\"People from the community benefiting from water projects\",\"form\":{\"name\":\"Full Name\",\"subject\":\"Subject\",\"email\":\"Email\",\"message\":\"Message\",\"submit\":\"SEND\",\"submittedAlert\":\"Form submitted successfully!\"}},\"footer\":{\"copy\":\"© {year} All rights reserved.\",\"privacyPolicy\":\"Privacy Policy\",\"legalNotice\":\"Legal Notice\",\"complaintsBook\":\"Complaints Book\",\"social\":{\"facebook\":\"AquaVita on Facebook\",\"linkedin\":\"AquaVita on LinkedIn\",\"instagram\":\"AquaVita on Instagram\"}},\"pages\":{\"ourMission\":{\"title\":\"Our Mission\",\"missionTitle\":\"Our Mission\",\"missionText\":\"Transform the way we use water to ensure a more sustainable and healthy world for everyone, especially for communities with water scarcity, through innovation, education, and collaboration.\",\"visionTitle\":\"Our Vision\",\"visionText\":\"Ensure that water is a valued resource used sustainably, achieving a healthy planet and a better quality of life today and for future generations.\",\"historyTitle\":\"Our History\"},\"solutions\":{\"bannerTitle\":\"Our Impact\",\"subtitle\":\"Discover how we transform the world, one drop at a time\",\"impactWaterSavedValue\":\"+5K\",\"impactWaterSavedLabel\":\"Liters of water saved annually per family\",\"impactSavingsValue\":\"+30%\",\"impactSavingsLabel\":\"Water and economic savings\",\"impactWaterDaysValue\":\"+6\",\"impactWaterDaysLabel\":\"Days of water in the home\",\"impactPeopleEmpoweredValue\":\"+200\",\"impactPeopleEmpoweredLabel\":\"People empowered as agents of change\",\"testimonialsTitle\":\"Projects - Testimonials\",\"testimonialsDescription\":\"Hear from those who have experienced our impact firsthand and see the projects that make a difference.\",\"testimonial1Quote\":\"AquaVita's project brought clean water to our village, changing our lives forever. We are healthier and more hopeful.\",\"testimonial1Author\":\"Maria, Community Leader\",\"testimonial2Quote\":\"The new irrigation system has boosted our crops and income. Thank you, AquaVita!\",\"testimonial2Author\":\"Juan, Farmer\",\"testimonial3Quote\":\"Learning about water conservation has empowered us to make sustainable choices for our families.\",\"testimonial3Author\":\"Elena, Workshop Participant\",\"odsSubtitle\":\"a sustainable future\",\"odsTitle\":\"Sustainable Development Goals\",\"odsDescription\":\"Discover how we contribute to the Sustainable Development Goals (SDGs) and contribute to positive change in communities that need access to water and better living conditions.\",\"odsCard3Title\":\"SDG 3: Good Health and Well-being\",\"odsCard3Description\":\"We contribute to well-being by improving personal hygiene and reducing the risk of diseases related to lack of access to drinking water and adequate hygiene.\",\"odsCard6Title\":\"SDG 6: Clean Water and Sanitation\",\"odsCard6Description\":\"We improve access to safe water, adequate hygiene, and efficient water use, benefiting the environment and society.\",\"odsCard10Title\":\"SDG 10: Reduced Inequalities\",\"odsCard10Description\":\"We provide access to basic resources like water, hygiene, and sustainability knowledge to disadvantaged communities, improving their quality of life.\",\"odsCard11Title\":\"SDG 11: Sustainable Cities\",\"odsCard11Description\":\"We promote sustainable management of water resources, helping people live in healthier communities.\",\"odsCard13Title\":\"SDG 13: Climate Action\",\"odsCard13Description\":\"We collaborate with the conservation of natural resources and provide tools for people to live in communities more resilient to climate change.\"},\"projects\":{\"title\":\"Projects\",\"alliesTitle\":\"Our Strategic Allies\",\"alliesDescription\":\"We have the support of:\",\"ally1\":\"Inter-American Development Bank\",\"ally2\":\"Startup Perú\",\"ally3\":\"American Society of Mechanical Engineers\",\"ally4\":\"Young Water Solutions\",\"ally5\":\"Municipality of Lima\",\"ally6\":\"Royal Academy of Engineering\",\"ally7\":\"Women4Climate\",\"ally8\":\"Kunan\",\"ally9\":\"SUNASS\",\"ally10\":\"Cewas\",\"ally11\":\"Protagonists of Change UPC\",\"ally12\":\"Young Leaders of the Americas Initiative\",\"ally13\":\"The Pollination Project\",\"ally14\":\"Universidad Científica del Sur\",\"ally15\":\"Agualimpia\",\"ally16\":\"Impact Hub Mexico City\",\"ally17\":\"Watsan\",\"ally18\":\"Eko Group H2O+\"},\"communitySupport\":{\"title\":\"Community Support\",\"introText\":\"Learn who supports us in our commitment to water and sustainability\",\"award1_title\":\"1st Place\",\"award1_description\":\"e-Hackathon in Water, Sanitation and Hygiene 2020 of the Inter-American Development Bank\",\"award2_title\":\"1st Place\",\"award2_description\":\"Lima, Women for Climate of the Municipality of Lima, C40 Cities and Cálidda\",\"award3_title\":\"Winners\",\"award3_description\":\"of the ASME Ishow 2022 of the American Society of Mechanical Engineers\",\"award4_title\":\"Winners\",\"award4_description\":\"of Startup Perú 8G+ program ProInnóvate of the Ministry of Production of Peru (Produce)\",\"award5_title\":\"Winners\",\"award5_description\":\"of the Protagonists of Change UPC program for the SDGs 2023\"},\"blog\":{\"title\":\"Blog\"},\"contact\":{\"title\":\"Contact Us\"},\"privacyPolicy\":{\"title\":\"Privacy Policy\"},\"legalNotice\":{\"title\":\"Legal Notice\"},\"complaintsBook\":{\"title\":\"Complaints Book\",\"mainTitle\":\"Wayru Perú Complaints Book\",\"introText1\":\"In accordance with the provisions of the Consumer Protection and Defense Code, we have a virtual Complaints Book at your disposal.\",\"companyNameRUC\":\"Wayru Perú SAC - RUC: 20607158402\",\"companyLocation\":\"Lima, Lima, Peru.\",\"formTitle\":\"Form\",\"dateLabel\":\"Date\",\"section1Title\":\"1. Identification of the consumer or claimant\",\"fullNameLabel\":\"Full name or company name*\",\"fullNamePlaceholder\":\"John Doe / XYZ Company Inc.\",\"idDocumentTypeLabel\":\"Identity document (select one)*\",\"idOptions\":{\"dni\":\"DNI\",\"pasaporte\":\"Passport\",\"carnetdeextranjeria\":\"Foreigner ID Card\",\"ruc\":\"RUC\"},\"idNumberLabel\":\"Identity Document Number*\",\"idNumberPlaceholder\":\"e.g., 12345678\",\"emailLabel\":\"Email address*\",\"emailPlaceholder\":\"email@example.com\",\"addressLabel\":\"Address\",\"addressPlaceholder\":\"123 Main St\",\"phoneLabel\":\"Phone\",\"phonePlaceholder\":\"987654321\",\"representativeLabel\":\"Representative (if minor)\",\"representativePlaceholder\":\"Name of representative\",\"section2Title\":\"2. Identification of the contracted good\",\"relatedToLabel\":\"The claim or complaint is related to a (select one or both)*\",\"relatedOptions\":{\"product\":\"Product\",\"service\":\"Service\"},\"acquisitionDateLabel\":\"Date of acquisition*\",\"datePlaceholder\":\"Select a date\",\"descriptionLabel\":\"Description*\",\"descriptionPlaceholder\":\"Describe the product or service\",\"section3Title\":\"3. Details of the claim\",\"claimTypeLabel\":\"Type of claim (select one)*\",\"claimTypes\":{\"claim\":\"Claim: Dissatisfaction related to products or services\",\"complaint\":\"Complaint: Dissatisfaction not related to products or services; or, discomfort or discontent regarding customer service\",\"claimShort\":\"Claim\",\"complaintShort\":\"Complaint\"},\"claimDetailLabel\":\"Detail or reason for the claim*\",\"claimDetailPlaceholder\":\"Describe your claim or complaint here...\",\"signatureLabel\":\"Claimant's signature\",\"signatureHelpText\":\"Optional. Attach a file if necessary. (File upload requires server configuration).\",\"nextButton\":\"Next\",\"backButton\":\"Back\",\"postNextText1\":\"It is important that you complete all data marked as \\\"mandatory\\\" in this claim/complaint form so that it can be properly evaluated and addressed.\",\"postNextText2\":\"Once the form is submitted, you will receive the claim sheet and an identification code via the email you provided.\",\"postNextText3\":\"It is important to note that there is a time limit of 30 calendar days to address your claim or complaint. However, in special cases, this maximum period may be extended, and the user will be notified through the contact method indicated in the form.\",\"postNextText4\":\"By submitting this claim or complaint form, you confirm that you have been informed about the procedure, the response time, and the means of response.\",\"sendButton\":\"Send\",\"submissionSuccessTitle\":\"Complaint Sent\",\"submissionSuccessMessage\":\"Your {claimType} with case number {caseNumber} has been registered. You will receive a copy in your email. (In a real application, a copy would also be sent to contacto@wayruperu.com).\",\"fieldRequiredError\":\"This field is required.\",\"invalidEmailError\":\"Invalid email address.\",\"selectAtLeastOneError\":\"Select at least one option (Product or Service).\"}}}"));}}),
"[project]/src/locales/es.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("{\"appName\":\"AquaVita\",\"nav\":{\"home\":\"Inicio\",\"ourMission\":\"Nuestra Misión\",\"solutions\":\"Nuestro Impacto\",\"projects\":\"Proyectos\",\"blog\":\"Blog\",\"contact\":\"Contacto\",\"language\":\"Idioma\"},\"loading\":\"Cargando...\",\"hero\":{},\"introCard\":{\"question\":\"¿Te imaginas vivir en un mundo sin agua? ¿Cómo realizarías actividades como cocinar, lavar los platos y asearte?\",\"statement\":\"Frente al contexto de escasez hídrica, Wayru llegó para redefinir el uso del agua, proporcionando sostenibilidad, bienestar e higiene en cada hogar.\"},\"phrases\":{\"phrase1\":\"1 de cada 3 personas en el mundo carecen de servicio de agua potable.\",\"phrase1_icon_alt\":\"Icono de personas\",\"phrase2\":\"3 millones de peruanos son afectados por esta situación.\",\"phrase2_icon_alt\":\"Icono de mapa de Perú\"},\"informativeVideo\":{\"title\":\"Nuestro Propósito\",\"description\":\"Somos una empresa social comprometida con mejorar la calidad de vida de las comunidades sin acceso a redes de agua potable y que enfrentan escasez hídrica. Buscamos:\",\"tab1_title\":\"Impactar\",\"tab1_content\":\"Impactar positivamente en la sociedad a través de proyectos sociales, talleres educativos y soluciones innovadoras.\",\"tab2_title\":\"Contribuir\",\"tab2_content\":\"Contribuir con el desarrollo sostenible, promoviendo la gestión responsable del agua y la conservación de nuestros recursos naturales.\",\"tab3_title\":\"Empoderar\",\"tab3_content\":\"Empoderar a más familias para que sean parte del cambio que nuestro planeta necesita, mediante prácticas sostenibles de disposición y consumo de agua.\",\"tab4_title\":\"Inspirar\",\"tab4_content\":\"Inspirar a más actores a unirse a nuestra causa y actuar frente a la escasez hídrica.\"},\"productSection\":{\"title\":\"Nuestro Producto Innovador\",\"item1_title\":\"Generación Atmosférica de Agua\",\"item1_description\":\"Tecnología de vanguardia que extrae agua potable pura directamente del aire, proporcionando una solución sostenible para regiones áridas.\",\"item2_title\":\"Filtración Inteligente de Agua\",\"item2_description\":\"Sistemas de filtración avanzados que garantizan agua segura y limpia, adaptables para hogares, comunidades y situaciones de emergencia.\",\"item3_title\":\"Kits de Conservación de Agua\",\"item3_description\":\"Kits fáciles de usar y materiales educativos para ayudar a los hogares a reducir el consumo de agua y adoptar hábitos de ahorro.\"},\"eventsSection\":{\"title\":\"Comunidad y Eventos\",\"event1_title\":\"Taller: Agua para Todos\",\"event1_description\":\"Únete a nuestro taller educativo sobre prácticas sostenibles del agua y participación comunitaria. Aprende cómo puedes marcar la diferencia.\",\"event2_title\":\"Evento Benéfico AquaRun\",\"event2_description\":\"Participa en nuestra carrera benéfica anual para recaudar fondos para proyectos de agua en comunidades desatendidas. ¡Cada paso cuenta!\",\"event3_title\":\"Cumbre de Innovación\",\"event3_description\":\"Descubre los últimos avances en tecnología y políticas del agua en nuestra cumbre anual. Conéctate con expertos y líderes.\"},\"newsSection\":{\"mainTitle\":\"Por una ciudad más feliz\",\"mainSubtitle\":\"Wayru, el proyecto con el objetivo de hacer una Lima más accesible al agua potable\",\"readMoreButton\":\"Leer Más\",\"item1\":{\"title\":\"“Por una ciudad más feliz”: Wayru, el proyecto con el objetivo de hacer una Lima más accesible al agua potable\",\"subtitle\":\"Entrevista para la revista Somos del diario peruano “El Comercio”\"},\"item2\":{\"title\":\"Emprendedoras combaten la crisis hídrica en Perú\",\"subtitle\":\"Entrevista para el diario chileno DF SUD\"},\"item3\":{\"title\":\"Innovadoras peruanas crean una ducha portátil que no necesita tuberías ni electricidad\",\"subtitle\":\"Nota de prensa en la agencia peruana de noticias “Andina”\"},\"item4\":{\"title\":\"Conoce a Wayru Perú ganadores del programa Protagonistas del Cambio UPC por los ODS 2023\",\"subtitle\":\"Nota de prensa en el periódico peruano “RPP”\"},\"item5\":{\"title\":\"Wayru Perú, finalista de Perumin Inspira 2023 atiende problema de acceso limitado al agua\",\"subtitle\":\"Entrevista en televisión para la plataforma “Red de Comunicación Regional (RCR)”.\"},\"item6\":{\"title\":\"Wayru Perú participa en evento internacional del BID y la ONU durante la Semana del Agua 2023\",\"subtitle\":\"Presentación en la conferencia “Fuente de Innovación: Acelerando el ODS 6” organizada por el Banco Interamericano de Desarrollo y las Naciones Unidas.\"},\"item7\":{\"title\":\"La ducha portátil llegó para revolucionar la higiene en los hogares peruanos\",\"subtitle\":\"Nota de prensa en el periódico gratuito internacional “Publimetro”\"},\"item8\":{\"title\":\"Emprendedores de EE.UU. y Perú ganan plazas en la cohorte anual ASME ISHOW con innovaciones accesibles en energía limpia y agua\",\"subtitle\":\"Nota de prensa de la “American Society of Mechanical Engineers (ASME)”\"},\"item9\":{\"title\":\"Geógrafa peruana ganó concurso internacional con proyecto de duchas portátiles\",\"subtitle\":\"Nota de prensa en el diario peruano “La República”.\"},\"item10\":{\"title\":\"Wayru en TV Perú: Soluciones Innovadoras para la Escasez de Agua\",\"subtitle\":\"Segmento en el programa \\\"Generación Bicentenario\\\" transmitido en la cadena de televisión pública TV Perú.\"},\"item11\":{\"title\":\"Alumnas y egresada PUCP son las creadoras de Wayru, proyecto que obtuvo el primer lugar en la E-Hackathon del BID\",\"subtitle\":\"Entrevista para el boletín “Punto Edu”, portal de noticias de la Pontificia Universidad Católica del Perú.\"}},\"impactSection\":{\"title\":\"¿Quieres saber cómo Wayru está transformando el mundo?\",\"description\":\"● Conoce más sobre nuestro impacto en las comunidades, el medio ambiente y la sociedad.\",\"shareLabel\":\"Comparte esta página:\",\"shareFacebook\":\"Compartir en Facebook\",\"shareTwitter\":\"Compartir en Twitter\",\"shareLinkedIn\":\"Compartir en LinkedIn\",\"shareEmail\":\"Compartir por correo electrónico\"},\"serParte\":{\"title\":\"Sé Parte del Cambio\",\"introText\":\"Tu contribución puede marcar una diferencia significativa. Explora cómo puedes involucrarte y ayudarnos a llevar agua limpia a más comunidades.\",\"prevSlide\":\"Diapositiva anterior\",\"nextSlide\":\"Siguiente diapositiva\",\"slide1_title\":\"Patrocina un proyecto\",\"slide1_description\":\"Empresas y personas pueden financiar proyectos específicos para llevar agua y educación ambiental a más comunidades. ¡Construyamos juntos!\",\"slide1_button\":\"Contáctanos\",\"slide2_title\":\"Inspira y enlaza\",\"slide2_description\":\"Comparte tus conocimientos o conéctanos con comunidades que puedan beneficiarse de nuestros proyectos. ¡Sé parte del impacto positivo!\",\"slide2_button\":\"Construye\",\"slide3_title\":\"Comparte nuestra labor\",\"slide3_description\":\"Síguenos en redes sociales y comparte nuestro trabajo con quienes te rodean. ¡Ayúdanos a expandir el mensaje de la sostenibilidad!\",\"slide3_button\":\"Difunde\",\"contactUs\":\"Contáctanos\",\"buildWithUs\":\"Construye con Nosotros\",\"form\":{\"description\":\"Completa el siguiente formulario y nos pondremos en contacto contigo en breve.\",\"name\":\"Nombre\",\"email\":\"Correo Electrónico\",\"message\":\"Mensaje\",\"send\":\"Enviar Mensaje\",\"submitted\":\"¡Gracias! Tu mensaje ha sido enviado.\"},\"social\":{\"title\":\"Difunde la Voz\",\"description\":\"Síguenos y comparte nuestra misión en tus redes sociales.\"}},\"alliesSection\":{\"title\":\"Juntos hacemos la diferencia\",\"description\":\"● Conoce a nuestros aliados que comparten nuestra visión y se suman a nuestro compromiso de crear un mundo más sostenible.\",\"button\":\"Conoce Más\"},\"homeContactSection\":{\"title\":\"Construyamos un futuro sostenible\",\"subtitle\":\"¡CONTÁCTANOS!\",\"imageAlt\":\"Personas de la comunidad beneficiándose de proyectos de agua\",\"form\":{\"name\":\"Nombre completo\",\"subject\":\"Asunto\",\"email\":\"Email\",\"message\":\"Mensaje\",\"submit\":\"ENVIAR\",\"submittedAlert\":\"¡Formulario enviado con éxito!\"}},\"footer\":{\"copy\":\"© {year} Todos los derechos reservados.\",\"privacyPolicy\":\"Política de Privacidad\",\"legalNotice\":\"Aviso Legal\",\"complaintsBook\":\"Libro de Reclamaciones\",\"social\":{\"facebook\":\"AquaVita en Facebook\",\"linkedin\":\"AquaVita en LinkedIn\",\"instagram\":\"AquaVita en Instagram\"}},\"pages\":{\"ourMission\":{\"title\":\"Nuestra Misión\",\"missionTitle\":\"Nuestra Misión\",\"missionText\":\"Transformar la forma en que usamos el agua para garantizar un mundo más sostenible y saludable para todos, especialmente para las comunidades con escasez hídrica, mediante la innovación, la educación y la colaboración.\",\"visionTitle\":\"Nuestra Visión\",\"visionText\":\"Garantizar que el agua sea un recurso valorado y utilizado de manera sostenible, logrando un planeta saludable y una mejor calidad de vida en la actualidad y para futuras generaciones.\",\"historyTitle\":\"Nuestra Historia\"},\"solutions\":{\"bannerTitle\":\"Nuestro Impacto\",\"subtitle\":\"Descubre cómo transformamos el mundo, una gota a la vez\",\"impactWaterSavedValue\":\"+5K\",\"impactWaterSavedLabel\":\"Litros de agua ahorrados anualmente por familia\",\"impactSavingsValue\":\"+30%\",\"impactSavingsLabel\":\"Ahorro hídrico y económico\",\"impactWaterDaysValue\":\"+6\",\"impactWaterDaysLabel\":\"Días de agua en el hogar\",\"impactPeopleEmpoweredValue\":\"+200\",\"impactPeopleEmpoweredLabel\":\"personas empoderadas como agentes de cambio\",\"testimonialsTitle\":\"Proyectos - Testimonios\",\"testimonialsDescription\":\"Escucha a quienes han experimentado nuestro impacto de primera mano y conoce los proyectos que marcan la diferencia.\",\"testimonial1Quote\":\"El proyecto de AquaVita trajo agua limpia a nuestra aldea, cambiando nuestras vidas para siempre. Estamos más saludables y esperanzados.\",\"testimonial1Author\":\"María, Líder Comunitaria\",\"testimonial2Quote\":\"El nuevo sistema de riego ha impulsado nuestros cultivos e ingresos. ¡Gracias, AquaVita!\",\"testimonial2Author\":\"Juan, Agricultor\",\"testimonial3Quote\":\"Aprender sobre la conservación del agua nos ha empoderado para tomar decisiones sostenibles para nuestras familias.\",\"testimonial3Author\":\"Elena, Participante del Taller\",\"odsSubtitle\":\"un futuro sostenible\",\"odsTitle\":\"Objetivos de Desarrollo Sostenible\",\"odsDescription\":\"Descubre cómo contribuimos a los Objetivos de Desarrollo Sostenible (ODS) y contribuimos al cambio positivo en comunidades que necesitan acceso al agua y mejores condiciones de vida.\",\"odsCard3Title\":\"ODS 3: Salud y Bienestar\",\"odsCard3Description\":\"Contribuimos al bienestar mejorando la higiene personal y reduciendo el riesgo de enfermedades relacionadas con la falta de acceso a agua potable e higiene adecuada.\",\"odsCard6Title\":\"ODS 6: Agua Limpia y Saneamiento\",\"odsCard6Description\":\"Mejoramos el acceso a agua segura, la higiene adecuada y el uso eficiente del agua, lo que beneficia al medio ambiente y la sociedad.\",\"odsCard10Title\":\"ODS 10: Reducción de las Desigualdades\",\"odsCard10Description\":\"Brindamos acceso a recursos básicos como el agua, la higiene, y conocimiento en sostenibilidad a comunidades desfavorecidas, mejorando su calidad de vida.\",\"odsCard11Title\":\"ODS 11: Ciudades Sostenibles\",\"odsCard11Description\":\"Promovemos la gestión sostenible de los recursos hídricos, ayudando a las personas a vivir en comunidades más saludables.\",\"odsCard13Title\":\"ODS 13: Acción por el Clima\",\"odsCard13Description\":\"Colaboramos con la conservación de los recursos naturales y damos herramientas a las personas para vivir en comunidades más resilientes al cambio climático.\"},\"projects\":{\"title\":\"Proyectos\",\"alliesTitle\":\"Nuestros aliados estratégicos\",\"alliesDescription\":\"Contamos con el apoyo de:\",\"ally1\":\"Banco Interamericano de Desarrollo\",\"ally2\":\"Startup Perú\",\"ally3\":\"American Society of Mechanical Engineers\",\"ally4\":\"Young Water Solutions\",\"ally5\":\"Municipalidad de Lima\",\"ally6\":\"Royal Academy of Engineering\",\"ally7\":\"Women4Climate\",\"ally8\":\"Kunan\",\"ally9\":\"SUNASS\",\"ally10\":\"Cewas\",\"ally11\":\"Protagonistas del Cambio UPC\",\"ally12\":\"Young Leaders of the Americas Initiative\",\"ally13\":\"The Pollination Project\",\"ally14\":\"Universidad Científica del Sur\",\"ally15\":\"Agualimpia\",\"ally16\":\"Impact Hub Ciudad de México\",\"ally17\":\"Watsan\",\"ally18\":\"Eko Group H2O+\"},\"communitySupport\":{\"title\":\"Apoyo de la comunidad\",\"introText\":\"Conoce quienes nos respaldan en nuestro compromiso con el agua y la sostenibilidad\",\"award1_title\":\"1ER LUGAR\",\"award1_description\":\"e-Hackathon en Agua, Saneamiento e Higiene 2020 del Banco Interamericano de Desarrollo\",\"award2_title\":\"1ER LUGAR\",\"award2_description\":\"Lima, Mujeres por el Clima de la Municipalidad de Lima, C40 Cities y Cálidda\",\"award3_title\":\"GANADORES\",\"award3_description\":\"del ASME Ishow 2022 del American Society of Mechanical Engineers\",\"award4_title\":\"GANADORES\",\"award4_description\":\"de Startup Perú 8G+ programa ProInnóvate del Ministerio de la Producción del Perú (Produce)\",\"award5_title\":\"GANADORES\",\"award5_description\":\"del programa Protagonistas del Cambio UPC por los ODS 2023\"},\"blog\":{\"title\":\"Blog\"},\"contact\":{\"title\":\"Contáctanos\"},\"privacyPolicy\":{\"title\":\"Política de Privacidad\"},\"legalNotice\":{\"title\":\"Aviso Legal\"},\"complaintsBook\":{\"title\":\"Libro de Reclamaciones\",\"mainTitle\":\"Libro de Reclamaciones Wayru Perú\",\"introText1\":\"Conforme a lo establecido en el Código de Protección y Defensa del Consumidor, contamos con un Libro de Reclamaciones virtual a su disposición.\",\"companyNameRUC\":\"Wayru Perú SAC - RUC: 20607158402\",\"companyLocation\":\"Lima, Lima, Perú.\",\"formTitle\":\"Formulario\",\"dateLabel\":\"Fecha\",\"section1Title\":\"1. Identificación del consumidor o reclamante\",\"fullNameLabel\":\"Nombre completo o razón social*\",\"fullNamePlaceholder\":\"Juan Pérez / Empresa XYZ S.A.C.\",\"idDocumentTypeLabel\":\"Documento de identidad (marcar una opción)*\",\"idOptions\":{\"dni\":\"DNI\",\"pasaporte\":\"Pasaporte\",\"carnetdeextranjeria\":\"Carnet de extranjería\",\"ruc\":\"RUC\"},\"idNumberLabel\":\"Número de Documento de Identidad*\",\"idNumberPlaceholder\":\"Ej: 12345678\",\"emailLabel\":\"Correo electrónico*\",\"emailPlaceholder\":\"correo@ejemplo.com\",\"addressLabel\":\"Dirección\",\"addressPlaceholder\":\"Av. Siempre Viva 123\",\"phoneLabel\":\"Teléfono\",\"phonePlaceholder\":\"987654321\",\"representativeLabel\":\"Apoderado (en el caso de ser menor de edad)\",\"representativePlaceholder\":\"Nombre del apoderado\",\"section2Title\":\"2. Identificación del bien contratado\",\"relatedToLabel\":\"El reclamo o queja está relacionado a un (marcar opción, puede ser una o ambas)*\",\"relatedOptions\":{\"product\":\"Producto\",\"service\":\"Servicio\"},\"acquisitionDateLabel\":\"Fecha de adquisición*\",\"datePlaceholder\":\"Seleccione una fecha\",\"descriptionLabel\":\"Descripción*\",\"descriptionPlaceholder\":\"Describa el producto o servicio\",\"section3Title\":\"3. Detalles de la reclamación\",\"claimTypeLabel\":\"Tipo de reclamo (marcar opción)*\",\"claimTypes\":{\"claim\":\"Reclamo: Disconformidad relacionada con los productos o servicios\",\"complaint\":\"Queja: Disconformidad no relacionada con los productos o servicios; o, malestar o descontento respecto a la atención al público\",\"claimShort\":\"Reclamo\",\"complaintShort\":\"Queja\"},\"claimDetailLabel\":\"Detalle o motivo de la reclamación*\",\"claimDetailPlaceholder\":\"Describa su reclamo o queja aquí...\",\"signatureLabel\":\"Firma del reclamante\",\"signatureHelpText\":\"Opcional. Adjunte un archivo si es necesario. (La carga de archivos requiere configuración del servidor).\",\"nextButton\":\"Siguiente\",\"backButton\":\"Anterior\",\"postNextText1\":\"Es importante que complete todos los datos señalados como \\\"obligatorios\\\" en el presente formulario de reclamo/queja para que pueda ser evaluado y atendido adecuadamente.\",\"postNextText2\":\"Una vez presentado el formulario, usted recibirá la hoja de reclamación y un código de identificación a través del correo electrónico que proporcionó.\",\"postNextText3\":\"Es importante destacar que existe un tiempo límite de 30 días calendario para atender su reclamo o queja. No obstante, en casos especiales, este período máximo puede ser extendido y se notificará al usuario a través del medio de contacto que indicó en el formulario.\",\"postNextText4\":\"Al enviar este formulario de reclamo o queja, usted confirma haber sido informado sobre el procedimiento, el plazo de atención y el medio de respuesta.\",\"sendButton\":\"Enviar\",\"submissionSuccessTitle\":\"Reclamación Enviada\",\"submissionSuccessMessage\":\"Su {claimType} con número de caso {caseNumber} ha sido registrada. Recibirá una copia en su correo electrónico. (En una aplicación real, también se enviaría una copia a contacto@wayruperu.com).\",\"fieldRequiredError\":\"Este campo es obligatorio.\",\"invalidEmailError\":\"Correo electrónico inválido.\",\"selectAtLeastOneError\":\"Seleccione al menos una opción (Producto o Servicio).\"}}}"));}}),
"[project]/src/context/I18nContext.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "I18nContext": (()=>I18nContext),
    "I18nProvider": (()=>I18nProvider)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$locales$2f$en$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/locales/en.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$locales$2f$es$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/locales/es.json (json)");
"use client";
;
;
;
;
const translations = {
    en: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$locales$2f$en$2e$json__$28$json$29$__["default"],
    es: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$locales$2f$es$2e$json__$28$json$29$__["default"]
};
const I18nContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function I18nProvider({ children }) {
    const [locale, setLocaleState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('es'); // Default to Spanish
    const setLocale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((newLocale)=>{
        setLocaleState(newLocale);
    }, []);
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((key, replacements)=>{
        const keys = key.split('.');
        let result = translations[locale];
        for (const k of keys){
            if (typeof result === 'object' && result !== null && k in result) {
                result = result[k];
            } else {
                result = undefined;
                break;
            }
        }
        if (typeof result === 'string') {
            if (replacements) {
                return Object.entries(replacements).reduce((acc, [placeholder, value])=>{
                    return acc.replace(`{{${placeholder}}}`, value);
                }, result);
            }
            return result;
        }
        // Fallback to English if translation not found in current locale
        if (locale !== 'en') {
            result = translations['en'];
            for (const k of keys){
                if (typeof result === 'object' && result !== null && k in result) {
                    result = result[k];
                } else {
                    return key; // Fallback to key if not found in English either
                }
            }
            if (typeof result === 'string') {
                if (replacements) {
                    return Object.entries(replacements).reduce((acc, [placeholder, value])=>{
                        return acc.replace(`{{${placeholder}}}`, value);
                    }, result);
                }
                return result;
            }
        }
        return key; // Fallback to key if not found
    }, [
        locale
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(I18nContext.Provider, {
        value: {
            locale,
            setLocale,
            t
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/I18nContext.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/context/LoadingContext.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "LoadingContext": (()=>LoadingContext),
    "LoadingProvider": (()=>LoadingProvider)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const LoadingContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LoadingProvider({ children }) {
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    // Simulate loading time
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setTimeout(()=>{
            setIsLoading(false);
        }, 3000); // Adjust time as needed
        return ()=>clearTimeout(timer);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LoadingContext.Provider, {
        value: {
            isLoading,
            setIsLoading
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/LoadingContext.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/components/layout/Providers.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Providers": (()=>Providers)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$I18nContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/I18nContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LoadingContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/LoadingContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
function Providers({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LoadingContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LoadingProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$I18nContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["I18nProvider"], {
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/layout/Providers.tsx",
            lineNumber: 14,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/layout/Providers.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "reducer": (()=>reducer),
    "toast": (()=>toast),
    "useToast": (()=>useToast)
});
// Inspired by react-hot-toast library
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
const TOAST_LIMIT = 1;
const TOAST_REMOVE_DELAY = 1000000;
const actionTypes = {
    ADD_TOAST: "ADD_TOAST",
    UPDATE_TOAST: "UPDATE_TOAST",
    DISMISS_TOAST: "DISMISS_TOAST",
    REMOVE_TOAST: "REMOVE_TOAST"
};
let count = 0;
function genId() {
    count = (count + 1) % Number.MAX_SAFE_INTEGER;
    return count.toString();
}
const toastTimeouts = new Map();
const addToRemoveQueue = (toastId)=>{
    if (toastTimeouts.has(toastId)) {
        return;
    }
    const timeout = setTimeout(()=>{
        toastTimeouts.delete(toastId);
        dispatch({
            type: "REMOVE_TOAST",
            toastId: toastId
        });
    }, TOAST_REMOVE_DELAY);
    toastTimeouts.set(toastId, timeout);
};
const reducer = (state, action)=>{
    switch(action.type){
        case "ADD_TOAST":
            return {
                ...state,
                toasts: [
                    action.toast,
                    ...state.toasts
                ].slice(0, TOAST_LIMIT)
            };
        case "UPDATE_TOAST":
            return {
                ...state,
                toasts: state.toasts.map((t)=>t.id === action.toast.id ? {
                        ...t,
                        ...action.toast
                    } : t)
            };
        case "DISMISS_TOAST":
            {
                const { toastId } = action;
                // ! Side effects ! - This could be extracted into a dismissToast() action,
                // but I'll keep it here for simplicity
                if (toastId) {
                    addToRemoveQueue(toastId);
                } else {
                    state.toasts.forEach((toast)=>{
                        addToRemoveQueue(toast.id);
                    });
                }
                return {
                    ...state,
                    toasts: state.toasts.map((t)=>t.id === toastId || toastId === undefined ? {
                            ...t,
                            open: false
                        } : t)
                };
            }
        case "REMOVE_TOAST":
            if (action.toastId === undefined) {
                return {
                    ...state,
                    toasts: []
                };
            }
            return {
                ...state,
                toasts: state.toasts.filter((t)=>t.id !== action.toastId)
            };
    }
};
const listeners = [];
let memoryState = {
    toasts: []
};
function dispatch(action) {
    memoryState = reducer(memoryState, action);
    listeners.forEach((listener)=>{
        listener(memoryState);
    });
}
function toast({ ...props }) {
    const id = genId();
    const update = (props)=>dispatch({
            type: "UPDATE_TOAST",
            toast: {
                ...props,
                id
            }
        });
    const dismiss = ()=>dispatch({
            type: "DISMISS_TOAST",
            toastId: id
        });
    dispatch({
        type: "ADD_TOAST",
        toast: {
            ...props,
            id,
            open: true,
            onOpenChange: (open)=>{
                if (!open) dismiss();
            }
        }
    });
    return {
        id: id,
        dismiss,
        update
    };
}
function useToast() {
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(memoryState);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        listeners.push(setState);
        return ()=>{
            const index = listeners.indexOf(setState);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        };
    }, [
        state
    ]);
    return {
        ...state,
        toast,
        dismiss: (toastId)=>dispatch({
                type: "DISMISS_TOAST",
                toastId
            })
    };
}
;
}}),
"[project]/src/lib/utils.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "cn": (()=>cn)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}}),
"[project]/src/components/ui/toast.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Toast": (()=>Toast),
    "ToastAction": (()=>ToastAction),
    "ToastClose": (()=>ToastClose),
    "ToastDescription": (()=>ToastDescription),
    "ToastProvider": (()=>ToastProvider),
    "ToastTitle": (()=>ToastTitle),
    "ToastViewport": (()=>ToastViewport)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-toast/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
const ToastProvider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Provider"];
const ToastViewport = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 16,
        columnNumber: 3
    }, this));
ToastViewport.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"].displayName;
const toastVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full", {
    variants: {
        variant: {
            default: "border bg-background text-foreground",
            destructive: "destructive group border-destructive bg-destructive text-destructive-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
const Toast = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, variant, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(toastVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
});
Toast.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"].displayName;
const ToastAction = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 62,
        columnNumber: 3
    }, this));
ToastAction.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"].displayName;
const ToastClose = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600", className),
        "toast-close": "",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/toast.tsx",
            lineNumber: 86,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 77,
        columnNumber: 3
    }, this));
ToastClose.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"].displayName;
const ToastTitle = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-sm font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 95,
        columnNumber: 3
    }, this));
ToastTitle.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"].displayName;
const ToastDescription = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-sm opacity-90", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toast.tsx",
        lineNumber: 107,
        columnNumber: 3
    }, this));
ToastDescription.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"].displayName;
;
}}),
"[project]/src/components/ui/toaster.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Toaster": (()=>Toaster)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/toast.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
function Toaster() {
    const { toasts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastProvider"], {
        children: [
            toasts.map(function({ id, title, description, action, ...props }) {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Toast"], {
                    ...props,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-1",
                            children: [
                                title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastTitle"], {
                                    children: title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/toaster.tsx",
                                    lineNumber: 22,
                                    columnNumber: 25
                                }, this),
                                description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastDescription"], {
                                    children: description
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/toaster.tsx",
                                    lineNumber: 24,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ui/toaster.tsx",
                            lineNumber: 21,
                            columnNumber: 13
                        }, this),
                        action,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastClose"], {}, void 0, false, {
                            fileName: "[project]/src/components/ui/toaster.tsx",
                            lineNumber: 28,
                            columnNumber: 13
                        }, this)
                    ]
                }, id, true, {
                    fileName: "[project]/src/components/ui/toaster.tsx",
                    lineNumber: 20,
                    columnNumber: 11
                }, this);
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastViewport"], {}, void 0, false, {
                fileName: "[project]/src/components/ui/toaster.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/toaster.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__f6ec414e._.js.map