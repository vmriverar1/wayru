(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_complaints-book_page_tsx_3dd7b9a6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_complaints-book_page_tsx_3dd7b9a6._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0593150e._.js",
    "static/chunks/src_fa58f9b4._.js",
    "static/chunks/node_modules_gsap_8ed0561d._.js",
    "static/chunks/node_modules_date-fns_e0d15fa9._.js",
    "static/chunks/node_modules_react-day-picker_dist_index_esm_9fc30424.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
    "static/chunks/node_modules_7edb61c9._.js"
  ],
  "source": "dynamic"
});
