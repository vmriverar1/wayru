(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_our-mission_page_tsx_3dd7b9a6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_our-mission_page_tsx_3dd7b9a6._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3bcf542a._.js",
    "static/chunks/src_ba6b1e92._.js",
    "static/chunks/node_modules_c7f37ec2._.js"
  ],
  "source": "dynamic"
});
