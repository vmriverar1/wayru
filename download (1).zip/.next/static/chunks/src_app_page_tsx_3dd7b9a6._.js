(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_3dd7b9a6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_3dd7b9a6._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_e3bbd64f._.js",
    "static/chunks/src_f78e47f0._.js",
    "static/chunks/node_modules_8a6c2bbe._.js"
  ],
  "source": "dynamic"
});
